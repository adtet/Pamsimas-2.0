package com.example.pamsimas10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    ImageButton login;
    EditText username,pin;
    DatabaseHelper db;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        login = (ImageButton)findViewById(R.id.btnlogin2);
        username = (EditText)findViewById(R.id.txtusernamelogin);
        pin = (EditText)findViewById(R.id.pinlogin);
        db = new DatabaseHelper(this);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = username.getText().toString();
                String mpin = pin.getText().toString();

                if(name.equals("")&&mpin.equals("")){
                    Toast.makeText(getApplicationContext(),"Isi data anda dengan lengkap",Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean checkdata = db.checkdata(name,mpin);
                    if(checkdata==true){

                        Boolean ins = db.insert5(name,mpin);
                        if(ins==true){
                            Toast.makeText(getApplicationContext(),"Selamat Datang",Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(Login.this,Menu.class);
                            Boolean param = db.checkParam();
                            if(param==true){
                                Toast.makeText(getApplicationContext(),"Selamat Datang",Toast.LENGTH_SHORT).show();
                                startActivity(i);
                                finish();
                            }
                            else{
                                startActivity(new Intent(Login.this,cParameter.class));
                                finish();
                            }
                        }
                        else{
                            Toast.makeText(getApplicationContext(),"ERROR",Toast.LENGTH_SHORT).show();
                        }

                    }
                    else Toast.makeText(getApplicationContext(),"Cek data anda", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
