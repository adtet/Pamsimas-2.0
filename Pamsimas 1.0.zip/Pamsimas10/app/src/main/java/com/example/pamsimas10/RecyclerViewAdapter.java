package com.example.pamsimas10;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    private ArrayList noPelangganList;
    private ArrayList namaPelangganList;
    private ArrayList angkaAwalList;
    private ArrayList bulanTagihList;
    private ArrayList alamatList;
    private ArrayList tahunList;

    RecyclerViewAdapter(ArrayList noPelangganlist, ArrayList namaPelangganlist, ArrayList angkaAwallist, ArrayList bulanTagihList,ArrayList alamatList,ArrayList tahunList ){
        this.noPelangganList = noPelangganlist;
        this.namaPelangganList = namaPelangganlist;
        this.angkaAwalList = angkaAwallist;
        this.bulanTagihList = bulanTagihList;
        this.alamatList = alamatList;
        this.tahunList = tahunList;
    }
    class ViewHolder extends RecyclerView.ViewHolder{
        private TextView mnoPelanggan,mnamaPelanggan,mangkaAwal,mbulan,malamat,mtahun;

        ViewHolder(View itemView){
            super(itemView);
            mnoPelanggan = itemView.findViewById(R.id.noPelangganR);
            mnamaPelanggan = itemView.findViewById(R.id.namaPelangganR);
            mangkaAwal = itemView.findViewById(R.id.angkaAwalR);
            mbulan = itemView.findViewById(R.id.bulanTagihR);
            malamat = itemView.findViewById(R.id.alamatR);
            mtahun = itemView.findViewById(R.id.tahunR);
        }
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.showdata,parent,false);
        return new ViewHolder(v);
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final String noPelanggan = (String) noPelangganList.get(position);
        final String namaPelanggan = (String)namaPelangganList.get(position);
        final String angkaAwal = (String)angkaAwalList.get(position);
        final String bulan = (String)bulanTagihList.get(position);
        final String alamat = (String)alamatList.get(position);
        final String tahun = (String)tahunList.get(position);
        holder.mnoPelanggan.setText(noPelanggan);
        holder.mnamaPelanggan.setText(namaPelanggan);
        holder.mangkaAwal.setText(angkaAwal);
        holder.mbulan.setText(bulan);
        holder.malamat.setText(alamat);
        holder.mtahun.setText(tahun);
    }
    @Override
    public int getItemCount() {
        return noPelangganList.size();
    }
}
