package com.example.pamsimas10;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.RelativeLayout;

import java.util.ArrayList;

public class ShowData extends AppCompatActivity {
    private DatabaseHelper db;

    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList noPelangganlist;
    private ArrayList namaPelangganlist;
    private ArrayList angkaAwallist;
    private ArrayList bulanlist;
    private ArrayList alamatlist;
    private ArrayList tahunlist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_data);
        bulanlist = new ArrayList<>();
        noPelangganlist = new ArrayList<>();
        namaPelangganlist = new ArrayList<>();
        angkaAwallist = new ArrayList<>();
        alamatlist = new ArrayList<>();
        tahunlist = new ArrayList<>();
        db = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recycler);
        getData();
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        adapter = new RecyclerViewAdapter(noPelangganlist,namaPelangganlist,angkaAwallist,bulanlist,alamatlist,tahunlist);
        recyclerView.setAdapter(adapter);
        DividerItemDecoration itemDecoration = new DividerItemDecoration(getApplicationContext(),DividerItemDecoration.VERTICAL);
        itemDecoration.setDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.line));
        recyclerView.addItemDecoration(itemDecoration);

    }
    protected void getData(){
        SQLiteDatabase readData = db.getReadableDatabase();
        Cursor cursor = readData.rawQuery("select * from tbpelanggan",null);
        cursor.moveToFirst();

        for(int i = 0;i<cursor.getCount();i++){
            cursor.moveToPosition(i);
            noPelangganlist.add(cursor.getString(0));
            namaPelangganlist.add(cursor.getString(1));
            angkaAwallist.add(cursor.getString(2));
            bulanlist.add(cursor.getString(3));
            alamatlist.add(cursor.getString(4));
            tahunlist.add(cursor.getString(5));
        }

    }
    public void onBackPressed(){finish();}
}
