package com.example.pamsimas10;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import java.util.Calendar;
import java.util.GregorianCalendar;

import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.zxing.Result;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class Deteksimeteran extends AppCompatActivity implements LocationListener {
    DatabaseHelper db;
    Login lg;
    Calendar kalender = new GregorianCalendar();
    LocationManager locationManager;
    FusedLocationProviderClient fusedLocationProviderClient;
    MapPoint mp;
    Location location;
    Context context;
    String provider,tgl;
    int bulan,tahun;
    public static EditText txtnopelanggan,txtakhir;
    ImageButton btnscan,btncari,btnreset,btninput;
    public static TextView txtlatitude,txtlongitude,txtnama,txtawal,txtbulantahun;
    private static final int REQUEST_CODE = 101;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deteksimeteran);
        db = new DatabaseHelper(this);
        mp = new MapPoint();
        lg = new Login();
        txtnopelanggan = findViewById(R.id.txtnopelangganCAM);
        txtnopelanggan.requestFocus();
        txtnama = findViewById(R.id.txtnamapelangganCAM);
        txtawal = findViewById(R.id.txtawalCAM);
        txtakhir = findViewById(R.id.txtakhirCAM);
        txtlatitude = findViewById(R.id.txtlatCAM);
        txtlongitude = findViewById(R.id.txtlongCAM);
        btnscan = findViewById(R.id.btnscanCAM);
        btncari = findViewById(R.id.btncariCAM);
        btnreset = findViewById(R.id.btnresetCAM);
        btninput = findViewById(R.id.btninputCAM);
        txtbulantahun = findViewById(R.id.bulantahunCAM);
        locationManager = (LocationManager)this.getSystemService(Context.LOCATION_SERVICE);
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        Criteria cf = new Criteria();
        bulan = kalender.get(Calendar.MONTH)+1;
        tahun = kalender.get(Calendar.YEAR);
        int date = kalender.get(Calendar.DATE);
        tgl = String.valueOf(tahun)+String.valueOf(bulan)+String.valueOf(date);
        fetchLastLocation();
        provider = locationManager.getBestProvider(cf,false);
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String []{Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_CODE);
        }
        location = locationManager.getLastKnownLocation(provider);
        if(location!=null) {
            double lng = location.getLongitude();
            double lat = location.getLatitude();
            String slng = String.valueOf(lng);
            String slat = String.valueOf(lat);
            txtlongitude.setText(slng);
            txtlatitude.setText(slat);
        }
        else{
            txtlongitude.setText("deny");
            txtlatitude.setText("deny");
        }
        btninput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String noPelanggan = txtnopelanggan.getText().toString();

                if(noPelanggan.equals("")){
                    Toast.makeText(getApplicationContext(),"Lengkapi data input",Toast.LENGTH_SHORT).show();
                }
                else{
                    String nama = txtnama.getText().toString();
                    String awal = txtawal.getText().toString();
                    int AWAL = Integer.parseInt(awal);
                    String akhir = txtakhir.getText().toString();
                    int AKHIR = Integer.parseInt(akhir);
                    String kodePdam = db.kodePdam();
                    String kodeRayon = db.kodeRayon();
                    String longi = txtlongitude.getText().toString();
                    String lat = txtlatitude.getText().toString();
                    String sbulan = String.valueOf(bulan);
                    String stahun = String.valueOf(tahun);
                    String username = db.username();
                    String tanggal = tgl;
                    if(AWAL>AKHIR){
                        Toast.makeText(getApplicationContext(),"cek angka awal dan akhir",Toast.LENGTH_SHORT).show();
                        txtakhir.setText("");
                    }
                    else {
                        Boolean ins = db.insert4(noPelanggan,nama,awal,akhir,kodePdam,kodeRayon,longi,lat,sbulan,stahun,username,tanggal);
                        if(ins==true){
                            Toast.makeText(getApplicationContext(),"Input data berhasil",Toast.LENGTH_SHORT).show();
                            txtnopelanggan.setText("");
                            txtnama.setText("Nama Pelanggan");
                            txtawal.setText("Angka Awal");
                            txtakhir.setText("");
                            txtnopelanggan.requestFocus();
                        }
                        else{
                            Toast.makeText(getApplicationContext(),"Input data gagal",Toast.LENGTH_SHORT).show();
                        }
                    }
                }

            }
        });
        btnreset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtnopelanggan.setText("");
                txtnama.setText("Nama Pelanggan");
                txtawal.setText("Angka Awal");
                txtakhir.setText("");
                txtbulantahun.setText("Bulan/Tahun");
                txtnopelanggan.requestFocus();
            }
        });
        btncari.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String b = txtnopelanggan.getText().toString();
                if(b.equals("")){
                    Toast.makeText(getApplicationContext(),"Lengkapi data",Toast.LENGTH_SHORT).show();
                }
                else {
                    String c = db.nama_pelanggan(b);
                    String e = db.angka_awal(b);
                    String d = db.bulantagih(b);
                    String f = db.tahuntagih(b);
                    txtnama.setText(c);
                    txtawal.setText(e);
                    txtbulantahun.setText(d+"/"+f);
                }
            }
        });
        btnscan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),ScannerQR.class));
                txtakhir.requestFocus();
            }
        });
    }
    @Override
    public void onLocationChanged(Location location) {
        double lng = location.getLongitude();
        double lat = location.getLatitude();
        String slng = String.valueOf(lng);
        String slat = String.valueOf(lat);
        txtlongitude.setText(slng);
        txtlatitude.setText(slat);
    }
    public void fetchLastLocation() {
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String []{Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_CODE);
        }
        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if(location!=null){
                    location = location;
                    Toast.makeText(getApplicationContext(), location.getLatitude()+"\n"+location.getLongitude(), Toast.LENGTH_SHORT).show();
                    double lng = location.getLongitude();
                    double lat = location.getLatitude();
                    String slng = String.valueOf(lng);
                    String slat = String.valueOf(lat);
                    txtlongitude.setText(slng);
                    txtlatitude.setText(slat);
                }
            }
        });
    }
    public void onBackPressed(){
        finish();
    }
}
