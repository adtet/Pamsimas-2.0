package com.example.pamsimas10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class cParameter extends AppCompatActivity {

    EditText txtnopdam,txtnorayon,txttahun,txturl;
    ImageButton input,server;
    DatabaseHelper db;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c_parameter);
        txtnopdam = findViewById(R.id.kodepdam1);
        txtnopdam.requestFocus();
        txtnorayon = findViewById(R.id.koderayon1);
        //txtbulan = findViewById(R.id.bulan1);
        server = findViewById(R.id.btnserver);
        txttahun = findViewById(R.id.tahun1);
        txturl = findViewById(R.id.alamatserver1);
        input = findViewById(R.id.btninputparameter);
        db = new DatabaseHelper(this);
        getdata();
        server.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String kodePdam = txtnopdam.getText().toString();
                txturl.setText("http://103.29.212.75:5002/pelanggan/"+kodePdam+"/");
            }
        });
        input.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String kodePdam = txtnopdam.getText().toString();
                String kodeRayon = txtnorayon.getText().toString();
                //String bulan = txtbulan.getText().toString();
                String tahun = txttahun.getText().toString();
                String url = txturl.getText().toString();

                if(kodePdam.equals("")&&kodeRayon.equals("")&&url.equals("")&&tahun.equals("")){
                    Toast.makeText(getApplicationContext(),"Lengkapi data anda",Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean check = db.checkKodePdam(kodePdam);
                    if(check==true){
                        Boolean check2 = db.checkKodeRayon(kodeRayon);
                        if(check2==true){
                            Boolean ins = db.insert2(kodePdam,kodeRayon,tahun,url);
                            if(ins==true){
                                Toast.makeText(getApplicationContext(),"Input data berhasil",Toast.LENGTH_SHORT).show();
                                txtnopdam.setText("");
                                txtnorayon.setText("");
                                txttahun.setText("");
                                txturl.setText("");
                                startActivity(new Intent(cParameter.this,Menu.class));
                                finish();
                            }
                            else {
                                Toast.makeText(getApplicationContext(),"Terjadi kesalahan",Toast.LENGTH_SHORT).show();
                            }
                        }
                        else {
                            Toast.makeText(getApplicationContext(),"Kode Rayon sudah digunakan",Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(getApplicationContext(),"Kode PDAM sudah digunakan",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
    public void onBackPressed(){
        finish();
    }
    public void getdata(){
        db = new DatabaseHelper(this);
        txtnopdam = findViewById(R.id.kodepdam1);
        txtnorayon = findViewById(R.id.koderayon1);
        //txtbulan = findViewById(R.id.bulan1);
        txttahun = findViewById(R.id.tahun1);
        txturl = findViewById(R.id.alamatserver1);
        SQLiteDatabase raed = db.getReadableDatabase();
        Cursor cursor = raed.rawQuery("Select * from tbparameter",null);
        cursor.moveToLast();
        if(cursor.getCount()>0){
            txtnopdam.setText(cursor.getString(0));
            txtnorayon.setText(cursor.getString(1));
            txttahun.setText(cursor.getString(2));
            txturl.setText(cursor.getString(3));
        }
        else{
            Toast.makeText(getApplicationContext(),"Isi parameter ",Toast.LENGTH_SHORT).show();
        }



    }
}
