package com.example.pamsimas10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class Register extends AppCompatActivity {

    ImageButton regist;
    EditText username,pin1,pin2;
    DatabaseHelper db;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        regist = findViewById(R.id.btnregist2);
        db = new DatabaseHelper(this);
        username = (EditText)findViewById(R.id.txtusernameregist);
        pin1 = (EditText)findViewById(R.id.pin1);
        pin2 = (EditText)findViewById(R.id.pin2);

        regist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = username.getText().toString();
                String mpin1 = pin1.getText().toString();
                String mpin2 = pin2.getText().toString();

                if(name.equals("")&&mpin1.equals("")&&mpin2.equals("")){
                    Toast.makeText(getApplicationContext(),"Isi data anda dengan lengkap",Toast.LENGTH_SHORT).show();
                }
                else{
                    if(mpin1.equals(mpin2)){
                        Boolean chekname = db.checkname(name);
                        if(chekname==true){
                            Boolean ins = db.insert(name,mpin1);
                            if(ins==true){
                                Toast.makeText(getApplicationContext(),"Registrasi Berhasil",Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(Register.this,MainActivity.class);
                                startActivity(i);
                                finish();
                            }
                            else Toast.makeText(getApplicationContext(),"Registrasi gagal",Toast.LENGTH_SHORT).show();
                        }
                        else Toast.makeText(getApplicationContext(),"Username telah digunakan",Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(getApplicationContext(),"Check pin anda",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
    public void onBackPressed(){
        finish();
    }
}
