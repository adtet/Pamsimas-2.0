package com.example.pamsimas10;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.icu.text.UnicodeSetSpanner;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class ShowData2 extends AppCompatActivity {
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList noPelangganlist;
    private ArrayList namaPelangganlist;
    private ArrayList awallist;
    private ArrayList akhirlist;
    private ArrayList usernamelist;
    private ArrayList tgllist;
    private DatabaseHelper db;
    ImageButton refresh;
    Button upload,hapus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_data2);
        noPelangganlist = new ArrayList<>();
        namaPelangganlist = new ArrayList<>();
        awallist = new ArrayList<>();
        akhirlist = new ArrayList<>();
        usernamelist = new ArrayList<>();
        tgllist = new ArrayList<>();
        db = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recycler2);
        refresh = findViewById(R.id.refresh);
        upload = findViewById(R.id.btnuploaddata);
        getData();
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        adapter = new RecyclerViewAdapter2(noPelangganlist,namaPelangganlist,awallist,akhirlist,usernamelist,tgllist,this);
        recyclerView.setAdapter(adapter);
        DividerItemDecoration itemDecoration = new DividerItemDecoration(getApplicationContext(),DividerItemDecoration.VERTICAL);
        itemDecoration.setDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.line));
        recyclerView.addItemDecoration(itemDecoration);

        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setRefresh();
            }
        });
        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                upload();
            }
        });
    }
    public void getData(){
        SQLiteDatabase read = db.getReadableDatabase();
        Cursor cursor = read.rawQuery("select * from tbtransaksi",null);
        cursor.moveToFirst();

        for(int i = 0;i<cursor.getCount();i++){
            cursor.moveToPosition(i);
            noPelangganlist.add(cursor.getString(0));
            namaPelangganlist.add(cursor.getString(1));
            awallist.add(cursor.getString(2));
            akhirlist.add(cursor.getString(3));
            usernamelist.add(cursor.getString(10));
            tgllist.add(cursor.getString(11));

        }
    }
    public void onBackPressed(){
        finish();
    }
    public void setRefresh(){
        noPelangganlist = new ArrayList<>();
        namaPelangganlist = new ArrayList<>();
        awallist = new ArrayList<>();
        akhirlist = new ArrayList<>();
        usernamelist = new ArrayList<>();
        tgllist = new ArrayList<>();
        db = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recycler2);
        refresh = findViewById(R.id.refresh);
        getData();
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        adapter = new RecyclerViewAdapter2(noPelangganlist,namaPelangganlist,awallist,akhirlist,usernamelist,tgllist,this);
        recyclerView.setAdapter(adapter);
        DividerItemDecoration itemDecoration = new DividerItemDecoration(getApplicationContext(),DividerItemDecoration.VERTICAL);
        itemDecoration.setDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.line));
        recyclerView.addItemDecoration(itemDecoration);
    }
    public void upload(){
        db = new DatabaseHelper(this);
        final Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://103.29.212.75:5002/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        JSONPlaceHolder jsonPlaceHolder = retrofit.create(JSONPlaceHolder.class);
        SQLiteDatabase read =  db.getReadableDatabase();
        Cursor cursor = read.rawQuery("Select * from tbtransaksi",null);
        cursor.moveToFirst();
        for(int i=0;i<cursor.getCount();i++){
            cursor.moveToPosition(i);
            String a = "";
            String b = "";
            String c = "";
            String d = "";
            String e = "";
            String f = "";
            a = cursor.getString(1);
            b = db.alamat(cursor.getString(0));
            c = cursor.getString(0);
            d = cursor.getString(3);
            e = cursor.getString(8);
            f = cursor.getString(9);
            Boolean check = db.checkupload(a,d);
            if(check==false){
                db.insertupdate(a,c,d,e,b,f);
                PostPelanggan postPelanggan = new PostPelanggan(a,c,d,e,b,f);
                Call<PostPelanggan>call = jsonPlaceHolder.createupload(postPelanggan);
                call.enqueue(new Callback<PostPelanggan>() {
                    @Override
                    public void onResponse(Call<PostPelanggan> call, Response<PostPelanggan> response) {
                        if(response.isSuccessful()){
                            Toast.makeText(getApplicationContext(),"Upload Data Berhasil",Toast.LENGTH_SHORT).show();
                        }
                    }
                    @Override
                    public void onFailure(Call<PostPelanggan> call, Throwable t) {
                        Toast.makeText(getApplicationContext(),"Cek Koneksi ke Server",Toast.LENGTH_SHORT).show();
                    }
                });
            }
            else {
                Toast.makeText(getApplicationContext(),"Data sudah ada",Toast.LENGTH_SHORT).show();
            }

        }

    }

}
