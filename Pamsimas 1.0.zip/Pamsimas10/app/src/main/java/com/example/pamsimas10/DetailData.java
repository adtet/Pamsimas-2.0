package com.example.pamsimas10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class DetailData extends AppCompatActivity {

    TextView txtnopelanggan,txtnamapelanggan,txtlong,txtlat,txtKodePdam,txtkodeRayon,txtbulan,txttahun,txtusername,txttanggal,txtawal;
    EditText txtakhir;
    String noPelanggan;
    Button btnupdate,btnhapus;
    DatabaseHelper db;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_data);
        txtnopelanggan = findViewById(R.id.nopelangganDetail);
        txtnamapelanggan = findViewById(R.id.namapelangganDetail);
        txtlong = findViewById(R.id.longitudeDetail);
        txtlat = findViewById(R.id.latitudeDetail);
        txtKodePdam = findViewById(R.id.kodePdamDetail);
        txtkodeRayon = findViewById(R.id.kodeRayonDetail);
        txtbulan = findViewById(R.id.bulanDetail);
        txttahun = findViewById(R.id.tahunDetail);
        txtusername = findViewById(R.id.usernameDetail);
        txttanggal = findViewById(R.id.tanggalDetail);
        txtawal = findViewById(R.id.angkawalDetail);
        txtakhir = findViewById(R.id.angkaakhirDetail);
        btnupdate = findViewById(R.id.btneditDetail);
        btnhapus = findViewById(R.id.btnhapusDetail);
        db = new DatabaseHelper(this);
        noPelanggan = getIntent().getStringExtra("noPelanggan");
        txtnopelanggan.setText(noPelanggan);
        getData(txtnopelanggan.getText().toString());
        btnupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Boolean edit = db.update1(txtnopelanggan.getText().toString(),txtawal.getText().toString(),txtakhir.getText().toString());
                if(edit==true){
                    Toast.makeText(getApplicationContext(),"Data berhasil di edit",Toast.LENGTH_SHORT).show();
                    finish();
                }
                else {
                    Toast.makeText(getApplicationContext(),"Terjadi kesalahan pada database server",Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnhapus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.delete1(txtnopelanggan.getText().toString());
                finish();
            }
        });

    }
    public void getData(String a){
        txtnamapelanggan = findViewById(R.id.namapelangganDetail);
        txtlong = findViewById(R.id.longitudeDetail);
        txtlat = findViewById(R.id.latitudeDetail);
        txtKodePdam = findViewById(R.id.kodePdamDetail);
        txtkodeRayon = findViewById(R.id.kodeRayonDetail);
        txtbulan = findViewById(R.id.bulanDetail);
        txttahun = findViewById(R.id.tahunDetail);
        txtusername = findViewById(R.id.usernameDetail);
        txttanggal = findViewById(R.id.tanggalDetail);
        txtawal = findViewById(R.id.angkawalDetail);
        txtakhir = findViewById(R.id.angkaakhirDetail);
        SQLiteDatabase read = db.getReadableDatabase();
        Cursor cursor = read.rawQuery("select * from tbtransaksi where no_pelanggan=?",new String[]{a});
        cursor.moveToFirst();
        if(cursor.getCount()>0){
            txtnamapelanggan.setText(cursor.getString(1));
            txtawal.setText(cursor.getString(2));
            txtakhir.setText(cursor.getString(3));
            txtKodePdam.setText(cursor.getString(4));
            txtkodeRayon.setText(cursor.getString(5));
            txtlong.setText(cursor.getString(6));
            txtlat.setText(cursor.getString(7));
            txtbulan.setText(cursor.getString(8));
            txttahun.setText(cursor.getString(9));
            txtusername.setText(cursor.getString(10));
            txttanggal.setText(cursor.getString(11));
        }
    }
    public void onBackPressed(){
        finish();
    }
}
